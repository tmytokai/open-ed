#include "setting.h"

#ifdef USE_TIMER

void init_timer( unsigned short period )
{
    T1CONbits.TMR1CS = 0b00; // タイマークロック = FOSC/4
    T1CONbits.T1CKPS = 0b11;  // prescale = x8,
    T1CONbits.TMR1ON = 1; // タイマーON

    TMR1 = period; // カウンターに値をセット
    PIR1bits.TMR1IF = 0; //割り込みフラグクリア

    INTCONbits.GIE = 1;   // 割り込み機能 ON
    INTCONbits.PEIE = 1; // PIExに載っている周辺装置(タイマーとか)からの割込を許可
    PIE1bits.TMR1IE = 1;  //タイマー１割り込み許可
}

#endif
