#include "config.h"
#include "setting.h"

void main(void){

    init();

    while(1){
    }

   return;
}
