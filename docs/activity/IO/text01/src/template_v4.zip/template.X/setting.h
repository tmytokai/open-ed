#ifndef _SETTING_H
#define _SETTING_H

// __delay_ms 関数を使う場合は define する必要があります
// OSCCONの設定と合わせてください(今回は 4 Mhz)
#define _XTAL_FREQ 4000000

// デジタル入力を使う場合はコメントアウトを解除してください
//#define USE_INPUT

//  シリアル通信を使う場合はコメントアウトを解除してください
//#define USE_UART

// A/D変換を使う場合はコメントアウトを解除してください
//#define USE_ADC

// CCPxを使う場合はコメントアウトを解除してください
//#define USE_CCP1
//#define USE_CCP2
//#define USE_CCP3
//#define USE_CCP4

// タイマー割り込みを使う場合はコメントアウトを解除してください
//#define USE_TIMER

#include <xc.h>

void init(void);

#ifdef USE_INPUT
void init_input(void);
#endif

#ifdef USE_UART
#include <stdio.h>
void init_uart(void);
#endif

#ifdef USE_ADC
void init_adc(void);
int adc(int chn);
#endif

#ifdef USE_CCP1
void init_ccp1(void);
#endif

#ifdef USE_CCP2
void init_ccp2(void);
#endif

#ifdef USE_CCP3
void init_ccp3(void);
#endif

#ifdef USE_CCP4
void init_ccp4(void);
#endif

#ifdef USE_TIMER
void init_timer( unsigned short period );
#endif

#endif
