#include "setting.h"

// 1827は CCP(Capture/Compare/PWM)モジュールを4つ(CCP1、CCP2、CCP3、CCP4) 積んでいます
// またタイマーモジュールを3つ(Timer2、Timer4、Timer6) 積んでるので同時に 3 つ PWM 出力可能です
// なお CCP1 と CCP2 は設定で出力ピンの位置を変更できます

#ifdef USE_CCP1

// CCP1 初期化
void init_ccp1()
{
    // 0 をセットするとRB3(9 pin) を CCP1 の出力とします
    // 1 をセットするとRB0(6 pin) を CCP1 の出力とします
    // 詳しくはデータシート 118p を参照してください
    APFCON0bits.CCP1SEL = ? ;

    // 動作モードを設定します
    // 0b1100 をセットすると PWM 出力モードになります
    // 詳しくはデータシート 204p を参照してください
    CCP1CONbits.CCP1M = ? ;

    // タイマーを接続します
    // 0b00 = Timer2、0b01 = Timer4、0b10 = Timer6
    // 詳しくはデータシート 206p を参照してください
    CCPTMRSbits.C1TSEL = ? ;

    // タイマーの prescale を設定します
    // 0b00 = x1、0b01 = x4、0b10 = x16、0b11 = x64
    // PWM 周期やパルス幅の計算で使います
    // 詳しくはデータシート 191p を参照してください
    T?CONbits.T?CKPS = ? ;

    // 1 をセットするとタイマーが ON になり PWM 出力が始まります
    // 詳しくはデータシート 191p を参照してください
    T?CONbits.TMR?ON = ? ;
}

#endif

#ifdef USE_CCP2

// CCP2 初期化
void init_ccp2()
{
    // 0 をセットするとRB6(12 pin) を CCP2 の出力とします
    // 1 をセットするとRA7(16 pin) を CCP2 の出力とします
    // 詳しくはデータシート 118p を参照してください
    APFCON0bits.CCP2SEL = ? ;

    // 動作モードを設定します
    // 0b1100 をセットすると PWM 出力モードになります
    // 詳しくはデータシート 204p を参照してください
    CCP2CONbits.CCP2M = ? ;

    // タイマーを接続します
    // 0b00 = Timer2、0b01 = Timer4、0b10 = Timer6
    // 詳しくはデータシート 206p を参照してください
    CCPTMRSbits.C2TSEL = ? ;

    // タイマーの prescale を設定します
    // 0b00 = x1、0b01 = x4、0b10 = x16、0b11 = x64
    // PWM 周期やパルス幅の計算で使います
    // 詳しくはデータシート 191p を参照してください
    T?CONbits.T?CKPS = ? ;

    // 1 をセットするとタイマーが ON になり PWM 出力が始まります
    // 詳しくはデータシート 191p を参照してください
    T?CONbits.TMR?ON = ? ;
}

#endif

#ifdef USE_CCP3

// CCP3 初期化
void init_ccp3()
{
    // CCP3 の出力は RA3(2 pin) 固定です

    // 動作モードを設定します
    // 0b1100 をセットすると PWM 出力モードになります
    // 詳しくはデータシート 204p を参照してください
    CCP3CONbits.CCP3M = ? ;

    // タイマーを接続します
    // 0b00 = Timer2、0b01 = Timer4、0b10 = Timer6
    // 詳しくはデータシート 206p を参照してください
    CCPTMRSbits.C3TSEL = ? ;

    // タイマーの prescale を設定します
    // 0b00 = x1、0b01 = x4、0b10 = x16、0b11 = x64
    // PWM 周期やパルス幅の計算で使います
    // 詳しくはデータシート 191p を参照してください
    T?CONbits.T?CKPS = ? ;

    // 1 をセットするとタイマーが ON になり PWM 出力が始まります
    // 詳しくはデータシート 191p を参照してください
    T?CONbits.TMR?ON = ? ;
}

#endif

#ifdef USE_CCP4

// CCP4 初期化
void init_ccp4()
{
    // CCP4 の出力は RA4(3 pin) 固定です

    // 動作モードを設定します
    // 0b1100 をセットすると PWM 出力モードになります
    // 詳しくはデータシート 204p を参照してください
    CCP4CONbits.CCP4M = ? ;

    // タイマーを接続します
    // 0b00 = Timer2、0b01 = Timer4、0b10 = Timer6
    // 詳しくはデータシート 206p を参照してください
    CCPTMRSbits.C4TSEL = ? ;

    // タイマーの prescale を設定します
    // 0b00 = x1、0b01 = x4、0b10 = x16、0b11 = x64
    // PWM 周期やパルス幅の計算で使います
    // 詳しくはデータシート 191p を参照してください
    T?CONbits.T?CKPS = ? ;

    // 1 をセットするとタイマーが ON になり PWM 出力が始まります
    // 詳しくはデータシート 191p を参照してください
    T?CONbits.TMR?ON = ? ;
}

#endif
