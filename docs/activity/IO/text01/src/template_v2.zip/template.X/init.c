#include "setting.h"

// 全体初期化
void init(void)
{
    // オシレータ(発振回路)の設定で、FOSC(Frequency of Oscillator)を 4 Mhz にセットしています
    // 今回は FOSC = 4 MHz (SPLLEN=0, IRCF=0b1101) としています
    // 詳しくはデータシート 67p を参照してください
    OSCCON = 0b01101000; 

    // ポート A,B を初期化します
    PORTA = 0x00; 
    PORTB = 0x00;

    // ポート A,B の入出力設定です
    // 0 にすると出力モード、1 にすると入力モードになります
    // 詳しくはデータシート 120p(ポートA)と126p(ポートB) を参照してください
    TRISA = 0b00000000;
    TRISB = 0b00000000;

    // ポート A,b のアナログ設定です
    // 0 にするとデジタル入出力モード、1 にするとアナログ入力モードになります
    // アナログ入力モードにする場合は対応する TRISx も入力モードにして下さい
    // 詳しくはデータシート 122p(ポートA)と128p(ポートB) を参照してください
    ANSELA = 0b00000000;
    ANSELB = 0b00000000;
    
    #ifdef USE_INPUT
    init_input();
    #endif

    #ifdef USE_UART
    init_uart();
    #endif

    #ifdef USE_ADC
    init_adc();
    #endif

    #ifdef USE_CCP1
    init_ccp1();
    #endif

    #ifdef USE_CCP2
    init_ccp2();
    #endif

    #ifdef USE_CCP3
    init_ccp3();
    #endif

    #ifdef USE_CCP4
    init_ccp4();
    #endif
}
